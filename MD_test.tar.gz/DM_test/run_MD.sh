#!/bin/bash

# Verifica si se proporcionó un archivo PDB
if [ $# -eq 0 ]; then
  echo "Error: se requiere un archivo PDB como entrada."
  exit 1
fi

# Nombre del archivo PDB
pdb_file=$1

# Verifica si el archivo PDB existe
if [ ! -f "$pdb_file" ]; then
  echo "Error: el archivo PDB especificado no existe."
  exit 1
fi

cp $pdb_file structure.pdb

### Preparation MD ###

#Using pdb2gmx to parameterize our PDB with the AMBER forcefield and SPC/E water
gmx pdb2gmx -f structure.pdb -o processed.pdb -water spce -ignh -ff amber99sb-ildn

#Using editconf to create a cubic box with 1.0 nm padding for our solvated system
gmx editconf -f processed.pdb -o newbox.pdb -c -d 1.0 -bt cubic

#Using solvate to fill up our box with water molecules
gmx solvate -cp newbox.pdb -o solv.pdb -p topol.top

#The charge of our solvated system is:
!grep "qtot" topol.top | awk 'END{print $(NF)'}

#Using grompp and an MD instruction file to add counterions to our system
gmx grompp -f ions.mdp -c solv.pdb -p topol.top -o ions.tpr

#This is a trick to provide interactive options to gmx
echo "SOL" > options
echo " " >> options

#Using genion and the tpr to add counterions to our solvated system
gmx genion -s ions.tpr -o solv_ions.pdb -p topol.top -pname NA -nname CL -neutral < options

### Minimization & Equilibration ###

#Using grompp to prepare our minimization MD
gmx grompp -f em.mdp -c solv_ions.pdb -p topol.top -o em.tpr

#Run our minimization
gmx mdrun -deffnm em -nb gpu

#This is a trick to provide interactive options to gmx
echo "Potential" > options
echo " " >> options

#Using energy to extract the potential energy of the system
gmx energy -f em.edr -o em_potential.xvg -xvg none < options

#Using grompp to prepare our NVT equilibration MD
gmx grompp -f nvt.mdp -c em.gro -r em.gro -p topol.top -o nvt.tpr

#Run our NVT equilibration MD
gmx mdrun -deffnm nvt -nb gpu

#This is a trick to provide interactive options to gmx
echo "Temperature" > options
echo " " >> options

#Using energy to extract the temperature of the system during the NVT equil MD
gmx energy -f nvt.edr -o nvt_temp.xvg -xvg none < options

#Using grompp to prepare our NPT equilibration MD
gmx grompp -f npt.mdp -c nvt.gro -r nvt.gro -t nvt.cpt -p topol.top -o npt.tpr

#Run our NPT equilibration MD
gmx mdrun -deffnm npt -nb gpu

#This is a trick to provide interactive options to gmx
echo "Pressure" > options
echo "Density" >> options
echo " "

#Using energy to extract the pressure and density of the system during the NPT equil MD
gmx energy -f npt.edr -o npt_press_dens.xvg -xvg none < options

### Running MD simulation ###

#Using grompp to prepare our production MD
gmx grompp -f md.mdp -c npt.gro -t npt.cpt -p topol.top -o md_1.tpr

#Run our production MD
gmx mdrun -deffnm md_1 -nb gpu

### Analysis Simulation ###

#This is a trick to provide interactive options to gmx
echo "Protein" > options
echo "Protein" >> options
echo " "

#Using trjconv to extract only the protein atoms from the simulation trajectory
#and also recenter the protein if its atoms crossed the periodic boundaries
gmx trjconv -s md_1.tpr -f md_1.xtc -o md_traj.pdb -pbc mol -center < options

#This is a trick to provide interactive options to gmx
echo "Backbone" > options
echo "Backbone" >> options
echo " "

#Compute RMSD
gmx rms -s md_1.tpr -f md_1.xtc -o rmsd.xvg -tu ns < options

#This is a trick to provide interactive options to gmx
echo "C-alpha" > options
echo " "

#Compute RMSF
gmx rmsf -f md_1.xtc -s md_1.tpr -o rmsf_all.xvg -res < options

